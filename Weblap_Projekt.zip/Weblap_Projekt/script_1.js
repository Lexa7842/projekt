// Kategóriák feltöltése a szotomb.js-ből
document.addEventListener('DOMContentLoaded', () => {
    const kategoriaSelect = document.getElementById('kategoria');

    Object.keys(szoTomb).forEach(kat => {
        const option = document.createElement('option');
        option.value = kat;
        option.textContent = kat.charAt(0).toUpperCase() + kat.slice(1);
        kategoriaSelect.appendChild(option);
    });
});
const kategoriaSelect = document.getElementById('kategoria');
if (kategoriaSelect && typeof szoTomb !== "undefined") {
    Object.keys(szoTomb).forEach(kat => {
        const option = document.createElement('option');
        option.value = kat;
        option.textContent = kat.charAt(0).toUpperCase() + kat.slice(1);
        kategoriaSelect.appendChild(option);
    });
}
// Időkorlát lenyitása/elrejtése
function toggleMenu() {
    const limit = document.querySelector('input[name="limit"]:checked').value;
    const timeMenu = document.getElementById('time-menu');
    timeMenu.style.display = (limit === 'yes') ? 'block' : 'none';
}

// Játék indítása - adatok mentése LocalStorage-ba
function inditas() {
    const kategoriaEl = document.getElementById('kategoria');
    const modEl = document.getElementById('mod');
    const limit = document.querySelector('input[name="limit"]:checked').value;
    const timeMenu = document.getElementById('time-menu');

    const settings = {
        kategoria: kategoriaEl.value,
        mod: modEl.value,
        idokorlat: limit === 'yes' ? Number(timeMenu.value) : null
    };

    console.log("MENTETT SETTINGS:", settings);

    localStorage.setItem('akasztofaSettings', JSON.stringify(settings));

    window.location.href = 'index2.html';
}