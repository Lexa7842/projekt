document.addEventListener('DOMContentLoaded', () => {
    const mentettAdatok = localStorage.getItem('akasztofaSettings');
    let beallitasok = { kategoria: "állatok", mod: "1", idokorlat: null };

    if (mentettAdatok) {
        try {
            const parsed = JSON.parse(mentettAdatok);
            beallitasok = {
                kategoria: parsed.kategoria || "állatok",
                mod: parsed.mod || "1",
                idokorlat: parsed.idokorlat ?? null
            };
        } catch (e) { console.log("Hiba:", e); }
    }

    let statNyert = 0;
    let statVesztett = 0;
    let kivalasztottSzo = "";
    let kitalaltBetuk = [];
    let hibak = 0;
    const maxHibak = 5;
    let hatralevoIdo = 0;
    let idozitoInterval;

    const hatterZene = document.getElementById('hatterZene');
    const halalZene = document.getElementById('halalZene');

    function frissitStatisztikaKijelzo() {
        $('#nyertSzamlalo').text(statNyert);
        $('#vesztettSzamlalo').text(statVesztett);
    }

    function jatekInditasa() {
        if (halalZene) {
            halalZene.pause();
            halalZene.currentTime = 0;
        }
        if (hatterZene) {
            hatterZene.volume = 0.15; 
            hatterZene.play().catch(e => console.log("Interakció kell"));
        }

        hibak = 0;
        kitalaltBetuk = [];
        $('#karakter').attr('src', `akasztas/kesz_0.png`);
        $('#tema-cim').text(`Kategória: ${beallitasok.kategoria}`);
        $('.modal').removeClass('show');

        const szavak = szoTomb[beallitasok.kategoria] || szoTomb['állatok'];
        kivalasztottSzo = szavak[Math.floor(Math.random() * szavak.length)].toUpperCase();
        
        if (beallitasok.idokorlat !== null && beallitasok.idokorlat > 0) {
            $('#idoDoboz').css('display', 'flex');
            hatralevoIdo = beallitasok.idokorlat * 60;
            frissitIdozito();
            clearInterval(idozitoInterval);
            idozitoInterval = setInterval(visszaszamlalas, 1000);
        } else {
            $('#idoDoboz').hide();
        }

        szivekRajzolasa();
        billentyuzetGeneralas();
        megjelenitSzo();
        frissitStatisztikaKijelzo();
    }

    function szivekRajzolasa() {
        const kontener = $('#eletekKontener');
        kontener.empty();
        for (let i = 0; i < maxHibak; i++) {
            kontener.append('<span class="sziv-ikon" id="sziv-' + i + '">❤️</span>');
        }
    }

    function billentyuzetGeneralas() {
        const tarolo = $('#betuBillentyu');
        tarolo.empty();
        const abc = "AÁBCDEÉFGHIÍJKLMNOÓÖŐPQRSTUÚÜŰVWXYZ".split("");
        abc.forEach(betu => {
            const btn = $('<button></button>').text(betu).addClass('billButton').on('click', function() {
                tippeles(betu, $(this));
            });
            tarolo.append(btn);
        });
    }

    function megjelenitSzo() {
        let megjelenitendo = "";
        let nyert = true;
        for (let betu of kivalasztottSzo) {
            if (kitalaltBetuk.includes(betu)) {
                megjelenitendo += betu + " ";
            } else {
                megjelenitendo += "_ ";
                nyert = false;
            }
        }
        $('#szoKijelzo').text(megjelenitendo.trim());
        if (nyert && kivalasztottSzo.length > 0) gyozelem();
    }

    function tippeles(betu, $btn) {
        if (kivalasztottSzo.includes(betu)) {
            kitalaltBetuk.push(betu);
            $btn.addClass('jo').prop('disabled', true);
            megjelenitSzo();
        } else {
            // 1. Szív kiválasztása és animáció indítása
            const aktualisSzivIndex = maxHibak - 1 - hibak;
            const $sziv = $(`#sziv-${aktualisSzivIndex}`);

            hibak++;
            $btn.addClass('rossz').prop('disabled', true);
            villanVer();

            // Szív animáció (elszáll és elhalványul)
            $sziv.animate({
                opacity: 0,
                top: "-40px",
                fontSize: "45px"
            }, 600, function() {
                $(this).css('visibility', 'hidden');
            });

            // 2. Halál vagy sima hiba logika
            if (hibak >= maxHibak) {
                // Letiltunk minden gombot azonnal
                $('#betuBillentyu button').prop('disabled', true);
                
                // Megvárjuk míg az utolsó kép is betöltődik
                frissitKep(() => {
                    setTimeout(() => {
                        halal();
                    }, 500);
                });
            } else {
                frissitKep();
            }
        }
    }

    // Módosított frissitKep: ha kap callback-et, megvárja a kép betöltését
    function frissitKep(callback) {
        const $karakter = $('#karakter');
        if (callback) {
            $karakter.one('load', callback); // Ha betöltődött az új src, fut a callback
        }
        $karakter.attr('src', `akasztas/kesz_${hibak}.png`);
        
        // Biztonsági mentés: ha a kép már gyorsítótárban van, a 'load' nem mindig sül el
        if (callback && $karakter[0].complete) {
            $karakter.off('load');
            callback();
        }
    }

    function villanVer() {
        $('#verEffekt').css('opacity', '1').fadeOut(400);
    }

    function visszaszamlalas() {
        hatralevoIdo--;
        frissitIdozito();
        if (hatralevoIdo <= 0) {
            clearInterval(idozitoInterval);
            halal();
        }
    }

    function frissitIdozito() {
        const perc = Math.floor(hatralevoIdo / 60);
        const mp = hatralevoIdo % 60;
        $('#szamlalo').text(`${perc}:${mp < 10 ? '0' : ''}${mp}`);
    }

    function gyozelem() {
        clearInterval(idozitoInterval);
        statNyert++;
        frissitStatisztikaKijelzo();
        $('#gyozModal').addClass('show');
    }

    function halal() {
        clearInterval(idozitoInterval);
        statVesztett++;
        frissitStatisztikaKijelzo();

        if (hatterZene) hatterZene.volume = 0.03; 
        if (halalZene) {
            halalZene.volume = 0.25; 
            halalZene.play();
        }

        $('#vesztettSzo').text("A szó ez volt: " + kivalasztottSzo);
        $('#halalModal').addClass('show');
    }

    $('#visszaGomb, #ujJatekGomb, #ujJatekGombGyoz').on('click', () => window.location.href = 'index1.html');
    $('#ujraGombHalal, #ujraGombGyoz, #oldalsoUjraGomb').on('click', jatekInditasa);

    jatekInditasa();
});