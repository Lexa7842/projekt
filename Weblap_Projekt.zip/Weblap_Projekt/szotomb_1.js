const szoTomb = {
  állatok: [
    "kutya","macska","ló","tehén","kecske","pók","páva","medve","oroszlán","tigris",
    "zebra","zsiráf","elefánt","delfin","cápa","pingvin","papagáj","kígyó","béka","mókus",
    "nyúl","róka","farkas","őz","szarvas","bálna","fóka","kenguru","strucc","antilop",
    "teknős","varjú","hód","csiga","hangya","darázs","csirke","kacsa","liba","tyúk"
  ],

  színek: [
    "piros","kék","zöld","sárga","lila","narancssárga","rózsaszín","barna","fekete","fehér",
    "szürke","arany","ezüst","bíbor","indigó","türkiz","bordó","olívazöld","mentazöld","korall"
  ],

  gyümölcsök: [
    "alma","körte","barack","szilva","cseresznye","meggy","eper","málna","áfonya","ribizli",
    "szeder","narancs","citrom","grapefruit","mandarin","lime","kivi","ananász","dinnye","mangó",
    "banán","szőlő","kókusz","gránátalma","avokádó"
  ],

  zöldségek: [
    "paradicsom","uborka","paprika","sárgarépa","hagyma","fokhagyma","saláta","spenót","brokkoli",
    "karfiol","káposzta","cukkini","padlizsán","bab","borsó","lencse","kukorica","retek","cékla"
  ],

  tudományok: [
    "fizika","kémia","biológia","matematika","informatika","csillagászat","geológia",
    "pszichológia","szociológia","filozófia","nyelvészet","történelem","orvostudomány",
    "genetika","neurológia","kvantummechanika","relativitáselmélet","evolúció"
  ],

  országok: [
    "magyarország","németország","franciaország","olaszország","spanyolország","portugália",
    "hollandia","belgium","svájc","ausztria","lengyelország","csehország","szlovákia",
    "románia","bulgária","görögország","törökország","oroszország","ukrajna","svédország",
    "norvégia","finnország","dánia"
  ],

  városok: [
    "budapest","debrecen","szeged","miskolc","pécs","győr","nyíregyháza","kecskemét",
    "székesfehérvár","szombathely","szolnok","tatabánya","kaposvár","békéscsaba",
    "sopron","eger","salgótarján","hódmezővásárhely"
  ],

  hobbik: [
    "futás","úszás","kerékpározás","túrázás","síelés","snowboardozás","tenisz","golf",
    "jóga","tánc","képzőművészet","zenehallgatás","olvasás","írás","főzés",
    "kertészkedés","fotózás","videójátékok","programozás","horgászat"
  ]
};